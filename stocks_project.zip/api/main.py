from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sqlite3
import pandas as pd
from joblib import load
import datetime
import os

DB = 'database/stocks.db'
MODEL_DIR = 'ml/models'

app = FastAPI(title='Stocks API')

class PredictRequest(BaseModel):
    ticker: str
    date: str  # YYYY-MM-DD

def load_model(ticker):
    path = os.path.join(MODEL_DIR, f'model_{ticker}.joblib')
    if not os.path.exists(path):
        raise FileNotFoundError(f'Model for {ticker} not found. Train models first.')
    return load(path)

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.post('/predict')
def predict(req: PredictRequest):
    ticker = req.ticker.upper()
    date_str = req.date
    try:
        dt = datetime.datetime.strptime(date_str, '%Y-%m-%d')
    except Exception as e:
        raise HTTPException(status_code=400, detail='Invalid date format, use YYYY-MM-DD')
    # Load model
    try:
        model = load_model(ticker)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    # Convert date to ordinal or numeric feature consistent with training
    x = [[dt.toordinal()]]
    pred = model.predict(x)[0]
    return {'ticker': ticker, 'date': date_str, 'predicted_close': float(pred)}
