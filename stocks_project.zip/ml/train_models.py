import sqlite3
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from joblib import dump
import os

DB = 'database/stocks.db'
MODELDIR = 'ml/models'
os.makedirs(MODELDIR, exist_ok=True)

TICKERS = ['VALE3.SA', 'PETR4.SA']

def load_table_for(ticker):
    table = 'stock_data_' + ticker.replace('.','_')
    conn = sqlite3.connect(DB)
    df = pd.read_sql(f"SELECT * FROM '{table}'", conn, parse_dates=['Date'])
    conn.close()
    return df

def train_for_ticker(ticker):
    print('Training for', ticker)
    df = load_table_for(ticker)
    # keep only non-null Close
    df = df.dropna(subset=['Close']).sort_values('Date')
    if len(df) < 10:
        print('Not enough data for', ticker)
        return
    # feature: date ordinal
    df['ord'] = df['Date'].map(pd.Timestamp.toordinal)
    X = df[['ord']].values
    y = df['Close'].values
    model = LinearRegression()
    model.fit(X, y)
    dump(model, os.path.join(MODELDIR, f'model_{ticker}.joblib'))
    print('Saved model for', ticker)

if __name__ == '__main__':
    for t in TICKERS:
        train_for_ticker(t)
    print('All done')
