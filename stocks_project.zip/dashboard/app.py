import streamlit as st
import pandas as pd
import sqlite3
import requests

st.set_page_config(layout='wide', page_title='Ações - VALE e PETR')

st.title('Dashboard de Ações — VALE3 e PETR4')

DB = 'database/stocks.db'
conn = sqlite3.connect(DB)
# Try to read tables for tickers
def load_df(table):
    try:
        return pd.read_sql(f"SELECT * FROM '{table}'", conn, parse_dates=['Date'])
    except Exception:
        return pd.DataFrame()

df_vale = load_df('stock_data_VALE3_SA')
df_petr = load_df('stock_data_PETR4_SA')

st.sidebar.header('Previsão')
ticker = st.sidebar.selectbox('Ticker', options=['VALE3.SA','PETR4.SA'])
date = st.sidebar.date_input('Data para previsão')

if st.sidebar.button('Pedir previsão'):
    try:
        resp = requests.post('http://localhost:8000/predict', json={'ticker': ticker, 'date': str(date)})
        if resp.ok:
            st.sidebar.success(f"Preço previsto: R$ {resp.json()['predicted_close']:.2f}")
        else:
            st.sidebar.error(f'Erro: {resp.text}')
    except Exception as e:
        st.sidebar.error('Não foi possível conectar à API. Rode uvicorn api.main:app --reload')

col1, col2 = st.columns(2)

with col1:
    st.subheader('VALE3.SA — Fechamento')
    if not df_vale.empty:
        df_vale = df_vale.sort_values('Date')
        st.line_chart(df_vale.set_index('Date')['Close'])
    else:
        st.info('Ainda não há dados para VALE3.SA. Rode etl/fetch_stocks.py')

with col2:
    st.subheader('PETR4.SA — Fechamento')
    if not df_petr.empty:
        df_petr = df_petr.sort_values('Date')
        st.line_chart(df_petr.set_index('Date')['Close'])
    else:
        st.info('Ainda não há dados para PETR4.SA. Rode etl/fetch_stocks.py')

st.markdown('---')
st.subheader('Dados (últimas linhas)')
if not df_vale.empty:
    st.write(df_vale.tail())
if not df_petr.empty:
    st.write(df_petr.tail())
