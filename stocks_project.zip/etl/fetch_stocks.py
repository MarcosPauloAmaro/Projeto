import yfinance as yf
import sqlite3
from datetime import datetime

DB = 'database/stocks.db'
TICKERS = ['VALE3.SA', 'PETR4.SA']

def save_df_to_sql(df, table_name):
    conn = sqlite3.connect(DB)
    df.to_sql(table_name, conn, if_exists='replace', index=True)
    conn.close()

def fetch_history(ticker, period='5y', interval='1d'):
    print(f'Fetching {ticker}...')
    df = yf.download(ticker, period=period, interval=interval)
    if df.empty:
        print(f'No data for {ticker}')
        return None
    df = df.reset_index()
    df['Ticker'] = ticker
    return df

if __name__ == '__main__':
    for t in TICKERS:
        df = fetch_history(t)
        if df is not None:
            save_df_to_sql(df[['Date','Open','High','Low','Close','Adj Close','Volume','Ticker']], 'stock_data_' + t.replace('.','_'))
    print('Done. Databases saved to', DB)
